
					</div>
				</div>
				<footer class="footer">
					<div class="container">
						<div class="row">
							<div class="col-12 text-muted text-center">
								&copy; 2024 <?php echo $config['web']['short_title'] ?>
							</div>
						</div>
					</div>
				</footer>
			</div>
		</div>
		
		<script src="<?php echo $config['web']['base_url'] ?>assets/js/jquery.core.js"></script>
		<script src="<?php echo $config['web']['base_url'] ?>assets/js/jquery.app.js"></script>

	</body>
</html>