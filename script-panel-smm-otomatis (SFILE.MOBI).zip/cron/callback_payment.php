 <?php
require("../mainconfig.php");

$json = file_get_contents("php://input");
print_r($json);

$data = json_decode($json);
$merchantRef = $data->id_reference ;

if ($data->status == 'success') {
   $ctrx = $db->query("SELECT * FROM deposits WHERE id_reference = '".$merchantRef."' AND status = 'Pending'");
        
        if ($ctrx->num_rows == 1) {
        
            $trx = $ctrx->fetch_assoc();
            $get_saldo = $trx['amount'];

            $db->query("UPDATE deposits SET status = 'Success' WHERE id = '".$trx['id']."'");
            
            $db->query("UPDATE users SET balance = balance+$get_saldo WHERE id = '".$trx['user_id']."'");
        } else {
          exit();
        }
} elseif($data->status == 'kadaluarsa'){
$ctrx = $db->query("SELECT * FROM deposits WHERE id_reference = '".$merchantRef."' AND status = 'Pending'");
        if ($ctrx->num_rows == 1) {
            $trx = $ctrx->fetch_assoc();
            $db->query("UPDATE deposits SET status = 'Canceled' WHERE id = '".$trx['id']."'");
        } else {
          exit();
        }
}
?>